using Microsoft.AspNetCore.Authorization;

namespace EmployeeManagement.Api.Features.Authorization;

public sealed class FunctionAccessRequirement(params string[] functionNames)
    : IAuthorizationRequirement
{
    public string[] FunctionNames { get; } = functionNames;
}
