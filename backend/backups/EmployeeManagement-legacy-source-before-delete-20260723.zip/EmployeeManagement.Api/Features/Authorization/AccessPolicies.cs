namespace EmployeeManagement.Api.Features.Authorization;

public static class AccessPolicies
{
    public const string UsersRead = "access.users.read";
    public const string UsersWrite = "access.users.write";
    public const string RolesRead = "access.roles.read";
    public const string RolesWrite = "access.roles.write";
    public const string FunctionsRead = "access.functions.read";
    public const string FunctionsWrite = "access.functions.write";
}
