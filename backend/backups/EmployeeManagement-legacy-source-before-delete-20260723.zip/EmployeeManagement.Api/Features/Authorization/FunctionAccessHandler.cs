using System.Security.Claims;
using EmployeeManagement.Api.Data.Legacy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Api.Features.Authorization;

public sealed class FunctionAccessHandler(
    LegacyAuthDbContext dbContext,
    IHttpContextAccessor httpContextAccessor)
    : AuthorizationHandler<FunctionAccessRequirement>
{
    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        FunctionAccessRequirement requirement)
    {
        var userIdValue = context.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdValue, out var userId) || requirement.FunctionNames.Length == 0)
        {
            return;
        }

        var cancellationToken = httpContextAccessor.HttpContext?.RequestAborted
            ?? CancellationToken.None;
        var hasAccess = await (
            from user in dbContext.Users.AsNoTracking()
            join userRole in dbContext.UserRoles.AsNoTracking() on user.Id equals userRole.UserId
            join roleFunction in dbContext.RoleFunctions.AsNoTracking()
                on userRole.RoleId equals roleFunction.RoleId
            join function in dbContext.Functions.AsNoTracking()
                on roleFunction.FunctionId equals function.Id
            where user.Id == userId &&
                  user.Disable != true &&
                  requirement.FunctionNames.Contains(function.Name) &&
                  (roleFunction.Right ?? 0) > 0
            select function.Id)
            .AnyAsync(cancellationToken);

        if (hasAccess)
        {
            context.Succeed(requirement);
        }
    }
}
