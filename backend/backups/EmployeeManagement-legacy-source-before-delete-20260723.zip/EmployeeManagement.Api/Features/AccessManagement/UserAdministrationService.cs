using System.ComponentModel.DataAnnotations;
using EmployeeManagement.Api.Common.Exceptions;
using EmployeeManagement.Api.Common.Models;
using EmployeeManagement.Api.Data.Legacy;
using EmployeeManagement.Api.Features.Auth;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Api.Features.AccessManagement;

public sealed class UserAdministrationService(
    LegacyAuthDbContext dbContext,
    ILegacyPasswordService passwordService) : IUserAdministrationService
{
    public async Task<PagedResponse<UserResponse>> GetPageAsync(
        UserListQuery query,
        CancellationToken cancellationToken)
    {
        var usersQuery = dbContext.Users.AsNoTracking();
        var search = query.Search?.Trim();
        if (!string.IsNullOrWhiteSpace(search))
        {
            usersQuery = usersQuery.Where(user =>
                user.UserName.Contains(search) || user.FullName.Contains(search));
        }

        if (query.Disabled.HasValue)
        {
            usersQuery = usersQuery.Where(user =>
                (user.Disable ?? false) == query.Disabled.Value);
        }

        var totalCount = await usersQuery.CountAsync(cancellationToken);
        var users = await usersQuery
            .OrderBy(user => user.UserName)
            .ThenBy(user => user.Id)
            .Skip((query.PageNumber - 1) * query.PageSize)
            .Take(query.PageSize)
            .ToListAsync(cancellationToken);
        var rolesByUser = await GetRolesByUserAsync(
            users.Select(user => user.Id).ToArray(),
            cancellationToken);
        var items = users
            .Select(user => MapUser(user, GetRoles(rolesByUser, user.Id)))
            .ToList();

        return new PagedResponse<UserResponse>(
            items,
            query.PageNumber,
            query.PageSize,
            totalCount,
            CalculateTotalPages(totalCount, query.PageSize));
    }

    public async Task<UserResponse> GetByIdAsync(Guid id, CancellationToken cancellationToken)
    {
        var user = await dbContext.Users
            .AsNoTracking()
            .SingleOrDefaultAsync(item => item.Id == id, cancellationToken)
            ?? throw new NotFoundException("Không tìm thấy tài khoản.");

        return await BuildResponseAsync(user, cancellationToken);
    }

    public async Task<UserResponse> CreateAsync(
        CreateUserRequest request,
        CancellationToken cancellationToken)
    {
        var userName = RequireTrimmed(request.UserName, "Tên đăng nhập là bắt buộc.");
        var fullName = RequireTrimmed(request.FullName, "Họ tên là bắt buộc.");
        await EnsureUserNameAvailableAsync(userName, null, cancellationToken);
        var roleIds = await ValidateRoleIdsAsync(request.RoleIds, cancellationToken);
        var now = DateTime.UtcNow;
        var user = new LegacyUser
        {
            Id = Guid.NewGuid(),
            UserName = userName,
            FullName = fullName,
            CreateTime = now,
            LastLoginTime = now,
            Disable = false
        };
        user.PasswordHash = passwordService.HashForStorage(user, request.Password);

        dbContext.Users.Add(user);
        foreach (var roleId in roleIds)
        {
            dbContext.UserRoles.Add(new LegacyUserRole
            {
                Id = Guid.NewGuid(),
                UserId = user.Id,
                RoleId = roleId
            });
        }

        await dbContext.SaveChangesAsync(cancellationToken);
        return await BuildResponseAsync(user, cancellationToken);
    }

    public async Task<UserResponse> UpdateAsync(
        Guid id,
        UpdateUserRequest request,
        CancellationToken cancellationToken)
    {
        var user = await GetTrackedUserAsync(id, cancellationToken);
        var userName = RequireTrimmed(request.UserName, "Tên đăng nhập là bắt buộc.");
        await EnsureUserNameAvailableAsync(userName, id, cancellationToken);
        user.UserName = userName;
        user.FullName = RequireTrimmed(request.FullName, "Họ tên là bắt buộc.");
        await dbContext.SaveChangesAsync(cancellationToken);

        return await BuildResponseAsync(user, cancellationToken);
    }

    public async Task<UserResponse> SetStatusAsync(
        Guid id,
        Guid currentUserId,
        SetUserStatusRequest request,
        CancellationToken cancellationToken)
    {
        if (id == currentUserId && request.Disabled)
        {
            throw new ConflictException("Không thể tự khóa tài khoản đang đăng nhập.");
        }

        var user = await GetTrackedUserAsync(id, cancellationToken);
        user.Disable = request.Disabled;
        await dbContext.SaveChangesAsync(cancellationToken);
        return await BuildResponseAsync(user, cancellationToken);
    }

    public async Task<UserResponse> SetRolesAsync(
        Guid id,
        Guid currentUserId,
        SetUserRolesRequest request,
        CancellationToken cancellationToken)
    {
        if (id == currentUserId)
        {
            throw new ConflictException("Không thể tự thay đổi vai trò của tài khoản đang đăng nhập.");
        }

        var user = await GetTrackedUserAsync(id, cancellationToken);
        var roleIds = await ValidateRoleIdsAsync(request.RoleIds, cancellationToken);
        var existingAssignments = await dbContext.UserRoles
            .Where(userRole => userRole.UserId == id)
            .ToListAsync(cancellationToken);
        dbContext.UserRoles.RemoveRange(existingAssignments);
        foreach (var roleId in roleIds)
        {
            dbContext.UserRoles.Add(new LegacyUserRole
            {
                Id = Guid.NewGuid(),
                UserId = id,
                RoleId = roleId
            });
        }

        await dbContext.SaveChangesAsync(cancellationToken);
        return await BuildResponseAsync(user, cancellationToken);
    }

    public async Task ResetPasswordAsync(
        Guid id,
        ResetPasswordRequest request,
        CancellationToken cancellationToken)
    {
        var user = await GetTrackedUserAsync(id, cancellationToken);
        user.PasswordHash = passwordService.HashForStorage(user, request.NewPassword);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteAsync(
        Guid id,
        Guid currentUserId,
        CancellationToken cancellationToken)
    {
        if (id == currentUserId)
        {
            throw new ConflictException("Không thể tự xóa tài khoản đang đăng nhập.");
        }

        var user = await GetTrackedUserAsync(id, cancellationToken);
        dbContext.Users.Remove(user);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task<LegacyUser> GetTrackedUserAsync(
        Guid id,
        CancellationToken cancellationToken) =>
        await dbContext.Users.SingleOrDefaultAsync(user => user.Id == id, cancellationToken)
        ?? throw new NotFoundException("Không tìm thấy tài khoản.");

    private async Task EnsureUserNameAvailableAsync(
        string userName,
        Guid? currentId,
        CancellationToken cancellationToken)
    {
        var exists = await dbContext.Users.AsNoTracking().AnyAsync(
            user => user.UserName == userName &&
                    (!currentId.HasValue || user.Id != currentId.Value),
            cancellationToken);
        if (exists)
        {
            throw new ConflictException("Tên đăng nhập đã tồn tại.");
        }
    }

    private async Task<Guid[]> ValidateRoleIdsAsync(
        IReadOnlyList<Guid> requestedRoleIds,
        CancellationToken cancellationToken)
    {
        var roleIds = requestedRoleIds.Distinct().ToArray();
        if (roleIds.Length != requestedRoleIds.Count)
        {
            throw new ValidationException("Danh sách vai trò không được chứa giá trị trùng.");
        }

        if (roleIds.Length == 0)
        {
            return roleIds;
        }

        var existingCount = await dbContext.Roles.AsNoTracking()
            .CountAsync(role => roleIds.Contains(role.Id), cancellationToken);
        if (existingCount != roleIds.Length)
        {
            throw new ValidationException("Một hoặc nhiều vai trò không tồn tại.");
        }

        return roleIds;
    }

    private async Task<UserResponse> BuildResponseAsync(
        LegacyUser user,
        CancellationToken cancellationToken)
    {
        var rolesByUser = await GetRolesByUserAsync([user.Id], cancellationToken);
        return MapUser(user, GetRoles(rolesByUser, user.Id));
    }

    private async Task<IReadOnlyDictionary<Guid, IReadOnlyList<RoleReferenceResponse>>>
        GetRolesByUserAsync(Guid[] userIds, CancellationToken cancellationToken)
    {
        if (userIds.Length == 0)
        {
            return new Dictionary<Guid, IReadOnlyList<RoleReferenceResponse>>();
        }

        var rows = await (
            from userRole in dbContext.UserRoles.AsNoTracking()
            join role in dbContext.Roles.AsNoTracking() on userRole.RoleId equals role.Id
            where userIds.Contains(userRole.UserId)
            orderby role.Name, role.Id
            select new { userRole.UserId, role.Id, role.Name, role.Description })
            .ToListAsync(cancellationToken);

        return rows
            .GroupBy(row => row.UserId)
            .ToDictionary(
                group => group.Key,
                group => (IReadOnlyList<RoleReferenceResponse>)group
                    .Select(row => new RoleReferenceResponse(row.Id, row.Name, row.Description))
                    .ToList());
    }

    private static IReadOnlyList<RoleReferenceResponse> GetRoles(
        IReadOnlyDictionary<Guid, IReadOnlyList<RoleReferenceResponse>> rolesByUser,
        Guid userId) =>
        rolesByUser.TryGetValue(userId, out var roles) ? roles : [];

    private static UserResponse MapUser(
        LegacyUser user,
        IReadOnlyList<RoleReferenceResponse> roles) =>
        new(
            user.Id,
            user.UserName,
            user.FullName,
            AsUtc(user.CreateTime),
            AsUtc(user.LastLoginTime),
            user.Disable ?? false,
            roles);

    private static int CalculateTotalPages(int totalCount, int pageSize) =>
        totalCount == 0 ? 0 : (int)Math.Ceiling(totalCount / (double)pageSize);

    private static string RequireTrimmed(string value, string message)
    {
        var trimmed = value.Trim();
        if (trimmed.Length == 0)
        {
            throw new ValidationException(message);
        }

        return trimmed;
    }

    private static DateTime AsUtc(DateTime value) =>
        value.Kind == DateTimeKind.Utc
            ? value
            : DateTime.SpecifyKind(value, DateTimeKind.Utc);
}
