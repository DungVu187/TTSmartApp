using System.ComponentModel.DataAnnotations;
using EmployeeManagement.Api.Common.Exceptions;
using EmployeeManagement.Api.Common.Models;
using EmployeeManagement.Api.Data.Legacy;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Api.Features.AccessManagement;

public sealed class RoleAdministrationService(LegacyAuthDbContext dbContext)
    : IRoleAdministrationService
{
    public async Task<PagedResponse<RoleListItemResponse>> GetPageAsync(
        RoleListQuery query,
        CancellationToken cancellationToken)
    {
        var rolesQuery = dbContext.Roles.AsNoTracking();
        var search = query.Search?.Trim();
        if (!string.IsNullOrWhiteSpace(search))
        {
            rolesQuery = rolesQuery.Where(role =>
                role.Name.Contains(search) || role.Description.Contains(search));
        }

        var totalCount = await rolesQuery.CountAsync(cancellationToken);
        var rows = await rolesQuery
            .OrderBy(role => role.Name)
            .ThenBy(role => role.Id)
            .Skip((query.PageNumber - 1) * query.PageSize)
            .Take(query.PageSize)
            .Select(role => new
            {
                role.Id,
                role.Name,
                role.Description,
                UserCount = dbContext.UserRoles.Count(userRole => userRole.RoleId == role.Id),
                FunctionCount = dbContext.RoleFunctions.Count(
                    roleFunction => roleFunction.RoleId == role.Id)
            })
            .ToListAsync(cancellationToken);
        var items = rows
            .Select(row => new RoleListItemResponse(
                row.Id,
                row.Name,
                row.Description,
                row.UserCount,
                row.FunctionCount))
            .ToList();

        return new PagedResponse<RoleListItemResponse>(
            items,
            query.PageNumber,
            query.PageSize,
            totalCount,
            totalCount == 0 ? 0 : (int)Math.Ceiling(totalCount / (double)query.PageSize));
    }

    public async Task<RoleResponse> GetByIdAsync(Guid id, CancellationToken cancellationToken)
    {
        var role = await dbContext.Roles
            .AsNoTracking()
            .SingleOrDefaultAsync(item => item.Id == id, cancellationToken)
            ?? throw new NotFoundException("Không tìm thấy vai trò.");

        return await BuildResponseAsync(role, cancellationToken);
    }

    public async Task<RoleResponse> CreateAsync(
        CreateRoleRequest request,
        CancellationToken cancellationToken)
    {
        var name = RequireName(request.Name);
        await EnsureNameAvailableAsync(name, null, cancellationToken);
        var role = new LegacyRole
        {
            Id = Guid.NewGuid(),
            Name = name,
            Description = request.Description.Trim()
        };
        dbContext.Roles.Add(role);
        await dbContext.SaveChangesAsync(cancellationToken);

        return await BuildResponseAsync(role, cancellationToken);
    }

    public async Task<RoleResponse> UpdateAsync(
        Guid id,
        UpdateRoleRequest request,
        CancellationToken cancellationToken)
    {
        var role = await GetTrackedRoleAsync(id, cancellationToken);
        var name = RequireName(request.Name);
        await EnsureNameAvailableAsync(name, id, cancellationToken);
        role.Name = name;
        role.Description = request.Description.Trim();
        await dbContext.SaveChangesAsync(cancellationToken);

        return await BuildResponseAsync(role, cancellationToken);
    }

    public async Task<RoleResponse> SetFunctionsAsync(
        Guid id,
        SetRoleFunctionsRequest request,
        CancellationToken cancellationToken)
    {
        var role = await GetTrackedRoleAsync(id, cancellationToken);
        var assignments = request.Functions;
        var functionIds = assignments.Select(item => item.FunctionId).ToArray();
        if (functionIds.Any(functionId => functionId == Guid.Empty))
        {
            throw new ValidationException("FunctionId không hợp lệ.");
        }

        if (functionIds.Distinct().Count() != functionIds.Length)
        {
            throw new ValidationException("Danh sách function không được chứa giá trị trùng.");
        }

        var functions = functionIds.Length == 0
            ? []
            : await dbContext.Functions.AsNoTracking()
                .Where(function => functionIds.Contains(function.Id))
                .ToListAsync(cancellationToken);
        if (functions.Count != functionIds.Length)
        {
            throw new ValidationException("Một hoặc nhiều function không tồn tại.");
        }

        var functionMap = functions.ToDictionary(function => function.Id);
        foreach (var assignment in assignments)
        {
            var possibleRight = functionMap[assignment.FunctionId].PossibleRight ?? 0;
            if ((assignment.Right & ~possibleRight) != 0)
            {
                throw new ValidationException(
                    $"Right của function '{functionMap[assignment.FunctionId].Name}' vượt quá PossibleRight.");
            }
        }

        var existingAssignments = await dbContext.RoleFunctions
            .Where(roleFunction => roleFunction.RoleId == id)
            .ToListAsync(cancellationToken);
        dbContext.RoleFunctions.RemoveRange(existingAssignments);
        foreach (var assignment in assignments)
        {
            dbContext.RoleFunctions.Add(new LegacyRoleFunction
            {
                Id = Guid.NewGuid(),
                RoleId = id,
                FunctionId = assignment.FunctionId,
                Right = assignment.Right
            });
        }

        await dbContext.SaveChangesAsync(cancellationToken);
        return await BuildResponseAsync(role, cancellationToken);
    }

    public async Task DeleteAsync(Guid id, CancellationToken cancellationToken)
    {
        var role = await GetTrackedRoleAsync(id, cancellationToken);
        if (await dbContext.UserRoles.AsNoTracking()
            .AnyAsync(userRole => userRole.RoleId == id, cancellationToken))
        {
            throw new ConflictException("Vai trò đang được gán cho tài khoản và chưa thể xóa.");
        }

        if (await dbContext.RoleFunctions.AsNoTracking()
            .AnyAsync(roleFunction => roleFunction.RoleId == id, cancellationToken))
        {
            throw new ConflictException("Vai trò đang có cấu hình function và chưa thể xóa.");
        }

        dbContext.Roles.Remove(role);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task<LegacyRole> GetTrackedRoleAsync(
        Guid id,
        CancellationToken cancellationToken) =>
        await dbContext.Roles.SingleOrDefaultAsync(role => role.Id == id, cancellationToken)
        ?? throw new NotFoundException("Không tìm thấy vai trò.");

    private async Task EnsureNameAvailableAsync(
        string name,
        Guid? currentId,
        CancellationToken cancellationToken)
    {
        var exists = await dbContext.Roles.AsNoTracking().AnyAsync(
            role => role.Name == name &&
                    (!currentId.HasValue || role.Id != currentId.Value),
            cancellationToken);
        if (exists)
        {
            throw new ConflictException("Tên vai trò đã tồn tại.");
        }
    }

    private async Task<RoleResponse> BuildResponseAsync(
        LegacyRole role,
        CancellationToken cancellationToken)
    {
        var userCount = await dbContext.UserRoles.AsNoTracking()
            .CountAsync(userRole => userRole.RoleId == role.Id, cancellationToken);
        var functions = await (
            from roleFunction in dbContext.RoleFunctions.AsNoTracking()
            join function in dbContext.Functions.AsNoTracking()
                on roleFunction.FunctionId equals function.Id
            where roleFunction.RoleId == role.Id
            orderby function.Description, function.Name, function.Id
            select new RoleFunctionResponse(
                function.Id,
                function.ParentFunctionId,
                function.Name,
                function.Description,
                roleFunction.Right ?? 0,
                function.PossibleRight ?? 0))
            .ToListAsync(cancellationToken);

        return new RoleResponse(
            role.Id,
            role.Name,
            role.Description,
            userCount,
            functions);
    }

    private static string RequireName(string value)
    {
        var name = value.Trim();
        if (name.Length == 0)
        {
            throw new ValidationException("Tên vai trò là bắt buộc.");
        }

        return name;
    }
}
