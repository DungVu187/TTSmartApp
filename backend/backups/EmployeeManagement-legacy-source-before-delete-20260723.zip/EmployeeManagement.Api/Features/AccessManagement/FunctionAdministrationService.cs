using System.ComponentModel.DataAnnotations;
using EmployeeManagement.Api.Common.Exceptions;
using EmployeeManagement.Api.Data.Legacy;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Api.Features.AccessManagement;

public sealed class FunctionAdministrationService(LegacyAuthDbContext dbContext)
    : IFunctionAdministrationService
{
    public async Task<IReadOnlyList<FunctionResponse>> GetListAsync(
        FunctionListQuery query,
        CancellationToken cancellationToken)
    {
        var functionsQuery = dbContext.Functions.AsNoTracking();
        var search = query.Search?.Trim();
        if (!string.IsNullOrWhiteSpace(search))
        {
            functionsQuery = functionsQuery.Where(function =>
                function.Name.Contains(search) || function.Description.Contains(search));
        }

        var rows = await functionsQuery
            .OrderBy(function => function.Description)
            .ThenBy(function => function.Name)
            .ThenBy(function => function.Id)
            .Select(function => new
            {
                function.Id,
                function.ParentFunctionId,
                function.Name,
                function.Description,
                PossibleRight = function.PossibleRight ?? 0,
                AssignedRoleCount = dbContext.RoleFunctions.Count(
                    roleFunction => roleFunction.FunctionId == function.Id)
            })
            .ToListAsync(cancellationToken);

        return rows
            .Select(row => new FunctionResponse(
                row.Id,
                row.ParentFunctionId,
                row.Name,
                row.Description,
                row.PossibleRight,
                row.AssignedRoleCount))
            .ToList();
    }

    public async Task<FunctionResponse> GetByIdAsync(
        Guid id,
        CancellationToken cancellationToken)
    {
        var function = await dbContext.Functions
            .AsNoTracking()
            .SingleOrDefaultAsync(item => item.Id == id, cancellationToken)
            ?? throw new NotFoundException("Không tìm thấy function.");

        return await BuildResponseAsync(function, cancellationToken);
    }

    public async Task<FunctionResponse> CreateAsync(
        CreateFunctionRequest request,
        CancellationToken cancellationToken)
    {
        var name = RequireName(request.Name);
        await EnsureNameAvailableAsync(name, null, cancellationToken);
        var id = Guid.NewGuid();
        await ValidateParentAsync(id, request.ParentFunctionId, cancellationToken);
        var function = new LegacyFunction
        {
            Id = id,
            ParentFunctionId = request.ParentFunctionId,
            Name = name,
            Description = request.Description.Trim(),
            PossibleRight = request.PossibleRight
        };
        dbContext.Functions.Add(function);
        await dbContext.SaveChangesAsync(cancellationToken);

        return await BuildResponseAsync(function, cancellationToken);
    }

    public async Task<FunctionResponse> UpdateAsync(
        Guid id,
        UpdateFunctionRequest request,
        CancellationToken cancellationToken)
    {
        var function = await GetTrackedFunctionAsync(id, cancellationToken);
        var name = RequireName(request.Name);
        await EnsureNameAvailableAsync(name, id, cancellationToken);
        await ValidateParentAsync(id, request.ParentFunctionId, cancellationToken);

        var assignedRights = await dbContext.RoleFunctions.AsNoTracking()
            .Where(roleFunction => roleFunction.FunctionId == id)
            .Select(roleFunction => roleFunction.Right ?? 0)
            .ToListAsync(cancellationToken);
        if (assignedRights.Any(right => (right & ~request.PossibleRight) != 0))
        {
            throw new ConflictException(
                "PossibleRight mới không bao phủ quyền đang được gán cho một hoặc nhiều vai trò.");
        }

        function.ParentFunctionId = request.ParentFunctionId;
        function.Name = name;
        function.Description = request.Description.Trim();
        function.PossibleRight = request.PossibleRight;
        await dbContext.SaveChangesAsync(cancellationToken);

        return await BuildResponseAsync(function, cancellationToken);
    }

    public async Task DeleteAsync(Guid id, CancellationToken cancellationToken)
    {
        var function = await GetTrackedFunctionAsync(id, cancellationToken);
        if (await dbContext.Functions.AsNoTracking()
            .AnyAsync(item => item.ParentFunctionId == id, cancellationToken))
        {
            throw new ConflictException("Function đang có function con và chưa thể xóa.");
        }

        if (await dbContext.RoleFunctions.AsNoTracking()
            .AnyAsync(roleFunction => roleFunction.FunctionId == id, cancellationToken))
        {
            throw new ConflictException("Function đang được gán cho vai trò và chưa thể xóa.");
        }

        dbContext.Functions.Remove(function);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task<LegacyFunction> GetTrackedFunctionAsync(
        Guid id,
        CancellationToken cancellationToken) =>
        await dbContext.Functions.SingleOrDefaultAsync(
            function => function.Id == id,
            cancellationToken)
        ?? throw new NotFoundException("Không tìm thấy function.");

    private async Task EnsureNameAvailableAsync(
        string name,
        Guid? currentId,
        CancellationToken cancellationToken)
    {
        var exists = await dbContext.Functions.AsNoTracking().AnyAsync(
            function => function.Name == name &&
                        (!currentId.HasValue || function.Id != currentId.Value),
            cancellationToken);
        if (exists)
        {
            throw new ConflictException("Tên function đã tồn tại.");
        }
    }

    private async Task ValidateParentAsync(
        Guid currentId,
        Guid? parentFunctionId,
        CancellationToken cancellationToken)
    {
        if (!parentFunctionId.HasValue)
        {
            return;
        }

        if (parentFunctionId.Value == currentId)
        {
            throw new ValidationException("Function không thể là cha của chính nó.");
        }

        var parentRows = await dbContext.Functions.AsNoTracking()
            .Select(function => new { function.Id, function.ParentFunctionId })
            .ToListAsync(cancellationToken);
        var parentMap = parentRows.ToDictionary(row => row.Id, row => row.ParentFunctionId);
        if (!parentMap.ContainsKey(parentFunctionId.Value))
        {
            throw new ValidationException("Function cha không tồn tại.");
        }

        var visited = new HashSet<Guid>();
        var cursor = parentFunctionId;
        while (cursor.HasValue)
        {
            if (cursor.Value == currentId || !visited.Add(cursor.Value))
            {
                throw new ConflictException("Cấu trúc function không được tạo vòng lặp.");
            }

            cursor = parentMap.TryGetValue(cursor.Value, out var nextParent)
                ? nextParent
                : null;
        }
    }

    private async Task<FunctionResponse> BuildResponseAsync(
        LegacyFunction function,
        CancellationToken cancellationToken)
    {
        var assignedRoleCount = await dbContext.RoleFunctions.AsNoTracking()
            .CountAsync(
                roleFunction => roleFunction.FunctionId == function.Id,
                cancellationToken);
        return new FunctionResponse(
            function.Id,
            function.ParentFunctionId,
            function.Name,
            function.Description,
            function.PossibleRight ?? 0,
            assignedRoleCount);
    }

    private static string RequireName(string value)
    {
        var name = value.Trim();
        if (name.Length == 0)
        {
            throw new ValidationException("Tên function là bắt buộc.");
        }

        return name;
    }
}
