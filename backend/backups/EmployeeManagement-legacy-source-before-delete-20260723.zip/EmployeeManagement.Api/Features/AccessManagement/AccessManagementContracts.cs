using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.Api.Features.AccessManagement;

public abstract class PagedQuery
{
    [Range(1, int.MaxValue, ErrorMessage = "Số trang phải lớn hơn hoặc bằng 1.")]
    public int PageNumber { get; init; } = 1;

    [Range(1, 100, ErrorMessage = "Kích thước trang phải từ 1 đến 100.")]
    public int PageSize { get; init; } = 20;
}

public sealed class UserListQuery : PagedQuery
{
    [StringLength(100, ErrorMessage = "Từ khóa tìm kiếm không được vượt quá 100 ký tự.")]
    public string? Search { get; init; }

    public bool? Disabled { get; init; }
}

public sealed class RoleListQuery : PagedQuery
{
    [StringLength(100, ErrorMessage = "Từ khóa tìm kiếm không được vượt quá 100 ký tự.")]
    public string? Search { get; init; }
}

public sealed class FunctionListQuery
{
    [StringLength(100, ErrorMessage = "Từ khóa tìm kiếm không được vượt quá 100 ký tự.")]
    public string? Search { get; init; }
}

public sealed record RoleReferenceResponse(
    Guid Id,
    string Name,
    string Description);

public sealed record UserResponse(
    Guid Id,
    string UserName,
    string FullName,
    DateTime CreateTime,
    DateTime LastLoginTime,
    bool Disabled,
    IReadOnlyList<RoleReferenceResponse> Roles);

public sealed class CreateUserRequest
{
    [Required(ErrorMessage = "Tên đăng nhập là bắt buộc.")]
    [StringLength(20, ErrorMessage = "Tên đăng nhập không được vượt quá 20 ký tự.")]
    public string UserName { get; init; } = string.Empty;

    [Required(ErrorMessage = "Họ tên là bắt buộc.")]
    [StringLength(50, ErrorMessage = "Họ tên không được vượt quá 50 ký tự.")]
    public string FullName { get; init; } = string.Empty;

    [Required(ErrorMessage = "Mật khẩu là bắt buộc.")]
    [StringLength(200, MinimumLength = 6, ErrorMessage = "Mật khẩu phải có từ 6 đến 200 ký tự.")]
    public string Password { get; init; } = string.Empty;

    public IReadOnlyList<Guid> RoleIds { get; init; } = [];
}

public sealed class UpdateUserRequest
{
    [Required(ErrorMessage = "Tên đăng nhập là bắt buộc.")]
    [StringLength(20, ErrorMessage = "Tên đăng nhập không được vượt quá 20 ký tự.")]
    public string UserName { get; init; } = string.Empty;

    [Required(ErrorMessage = "Họ tên là bắt buộc.")]
    [StringLength(50, ErrorMessage = "Họ tên không được vượt quá 50 ký tự.")]
    public string FullName { get; init; } = string.Empty;
}

public sealed class SetUserStatusRequest
{
    public bool Disabled { get; init; }
}

public sealed class SetUserRolesRequest
{
    public IReadOnlyList<Guid> RoleIds { get; init; } = [];
}

public sealed class ResetPasswordRequest
{
    [Required(ErrorMessage = "Mật khẩu mới là bắt buộc.")]
    [StringLength(200, MinimumLength = 6, ErrorMessage = "Mật khẩu mới phải có từ 6 đến 200 ký tự.")]
    public string NewPassword { get; init; } = string.Empty;
}

public sealed record RoleListItemResponse(
    Guid Id,
    string Name,
    string Description,
    int UserCount,
    int FunctionCount);

public sealed record RoleFunctionResponse(
    Guid FunctionId,
    Guid? ParentFunctionId,
    string Name,
    string Description,
    int Right,
    int PossibleRight);

public sealed record RoleResponse(
    Guid Id,
    string Name,
    string Description,
    int UserCount,
    IReadOnlyList<RoleFunctionResponse> Functions);

public sealed class CreateRoleRequest
{
    [Required(ErrorMessage = "Tên vai trò là bắt buộc.")]
    [StringLength(50, ErrorMessage = "Tên vai trò không được vượt quá 50 ký tự.")]
    public string Name { get; init; } = string.Empty;

    [StringLength(200, ErrorMessage = "Mô tả vai trò không được vượt quá 200 ký tự.")]
    public string Description { get; init; } = string.Empty;
}

public sealed class UpdateRoleRequest
{
    [Required(ErrorMessage = "Tên vai trò là bắt buộc.")]
    [StringLength(50, ErrorMessage = "Tên vai trò không được vượt quá 50 ký tự.")]
    public string Name { get; init; } = string.Empty;

    [StringLength(200, ErrorMessage = "Mô tả vai trò không được vượt quá 200 ký tự.")]
    public string Description { get; init; } = string.Empty;
}

public sealed class RoleFunctionAssignmentRequest
{
    public Guid FunctionId { get; init; }

    [Range(0, int.MaxValue, ErrorMessage = "Giá trị quyền không được âm.")]
    public int Right { get; init; }
}

public sealed class SetRoleFunctionsRequest
{
    public IReadOnlyList<RoleFunctionAssignmentRequest> Functions { get; init; } = [];
}

public sealed record FunctionResponse(
    Guid Id,
    Guid? ParentFunctionId,
    string Name,
    string Description,
    int PossibleRight,
    int AssignedRoleCount);

public sealed class CreateFunctionRequest
{
    public Guid? ParentFunctionId { get; init; }

    [Required(ErrorMessage = "Tên function là bắt buộc.")]
    [StringLength(50, ErrorMessage = "Tên function không được vượt quá 50 ký tự.")]
    public string Name { get; init; } = string.Empty;

    [StringLength(100, ErrorMessage = "Mô tả function không được vượt quá 100 ký tự.")]
    public string Description { get; init; } = string.Empty;

    [Range(0, int.MaxValue, ErrorMessage = "PossibleRight không được âm.")]
    public int PossibleRight { get; init; }
}

public sealed class UpdateFunctionRequest
{
    public Guid? ParentFunctionId { get; init; }

    [Required(ErrorMessage = "Tên function là bắt buộc.")]
    [StringLength(50, ErrorMessage = "Tên function không được vượt quá 50 ký tự.")]
    public string Name { get; init; } = string.Empty;

    [StringLength(100, ErrorMessage = "Mô tả function không được vượt quá 100 ký tự.")]
    public string Description { get; init; } = string.Empty;

    [Range(0, int.MaxValue, ErrorMessage = "PossibleRight không được âm.")]
    public int PossibleRight { get; init; }
}
