using EmployeeManagement.Api.Common.Models;

namespace EmployeeManagement.Api.Features.AccessManagement;

public interface IUserAdministrationService
{
    Task<PagedResponse<UserResponse>> GetPageAsync(
        UserListQuery query,
        CancellationToken cancellationToken);

    Task<UserResponse> GetByIdAsync(Guid id, CancellationToken cancellationToken);

    Task<UserResponse> CreateAsync(
        CreateUserRequest request,
        CancellationToken cancellationToken);

    Task<UserResponse> UpdateAsync(
        Guid id,
        UpdateUserRequest request,
        CancellationToken cancellationToken);

    Task<UserResponse> SetStatusAsync(
        Guid id,
        Guid currentUserId,
        SetUserStatusRequest request,
        CancellationToken cancellationToken);

    Task<UserResponse> SetRolesAsync(
        Guid id,
        Guid currentUserId,
        SetUserRolesRequest request,
        CancellationToken cancellationToken);

    Task ResetPasswordAsync(
        Guid id,
        ResetPasswordRequest request,
        CancellationToken cancellationToken);

    Task DeleteAsync(Guid id, Guid currentUserId, CancellationToken cancellationToken);
}

public interface IRoleAdministrationService
{
    Task<PagedResponse<RoleListItemResponse>> GetPageAsync(
        RoleListQuery query,
        CancellationToken cancellationToken);

    Task<RoleResponse> GetByIdAsync(Guid id, CancellationToken cancellationToken);

    Task<RoleResponse> CreateAsync(
        CreateRoleRequest request,
        CancellationToken cancellationToken);

    Task<RoleResponse> UpdateAsync(
        Guid id,
        UpdateRoleRequest request,
        CancellationToken cancellationToken);

    Task<RoleResponse> SetFunctionsAsync(
        Guid id,
        SetRoleFunctionsRequest request,
        CancellationToken cancellationToken);

    Task DeleteAsync(Guid id, CancellationToken cancellationToken);
}

public interface IFunctionAdministrationService
{
    Task<IReadOnlyList<FunctionResponse>> GetListAsync(
        FunctionListQuery query,
        CancellationToken cancellationToken);

    Task<FunctionResponse> GetByIdAsync(Guid id, CancellationToken cancellationToken);

    Task<FunctionResponse> CreateAsync(
        CreateFunctionRequest request,
        CancellationToken cancellationToken);

    Task<FunctionResponse> UpdateAsync(
        Guid id,
        UpdateFunctionRequest request,
        CancellationToken cancellationToken);

    Task DeleteAsync(Guid id, CancellationToken cancellationToken);
}
