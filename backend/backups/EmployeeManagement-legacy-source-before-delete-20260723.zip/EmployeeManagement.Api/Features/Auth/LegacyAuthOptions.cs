namespace EmployeeManagement.Api.Features.Auth;

public sealed class LegacyAuthOptions
{
    public const string SectionName = "LegacyAuth";

    public bool UpgradeLegacyPasswordHash { get; init; }

    public LegacyPasswordWriteMode PasswordWriteMode { get; init; } =
        LegacyPasswordWriteMode.Md5Utf8;
}

public enum LegacyPasswordWriteMode
{
    Md5Utf8,
    Md5Unicode,
    AspNetIdentity
}
