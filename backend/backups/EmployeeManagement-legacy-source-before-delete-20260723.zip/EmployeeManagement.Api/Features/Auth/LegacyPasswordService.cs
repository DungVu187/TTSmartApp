using System.Security.Cryptography;
using System.Text;
using EmployeeManagement.Api.Data.Legacy;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;

namespace EmployeeManagement.Api.Features.Auth;

public sealed class LegacyPasswordService(
    IPasswordHasher<LegacyUser> passwordHasher,
    IOptions<LegacyAuthOptions> options) : ILegacyPasswordService
{
    private readonly LegacyAuthOptions legacyAuthOptions = options.Value;

    public LegacyPasswordVerification Verify(LegacyUser user, string password)
    {
        if (user.PasswordHash.StartsWith("AQAAAA", StringComparison.Ordinal))
        {
            var result = passwordHasher.VerifyHashedPassword(user, user.PasswordHash, password);
            return result switch
            {
                PasswordVerificationResult.Success => new LegacyPasswordVerification(true, false, false),
                PasswordVerificationResult.SuccessRehashNeeded => new LegacyPasswordVerification(true, true, false),
                _ => new LegacyPasswordVerification(false, false, false)
            };
        }

        var isValid = VerifyLegacyMd5(user.PasswordHash, password);
        return new LegacyPasswordVerification(isValid, isValid, true);
    }

    public string HashForStorage(LegacyUser user, string password) =>
        legacyAuthOptions.PasswordWriteMode switch
        {
            LegacyPasswordWriteMode.Md5Utf8 => HashMd5(password, Encoding.UTF8),
            LegacyPasswordWriteMode.Md5Unicode => HashMd5(password, Encoding.Unicode),
            LegacyPasswordWriteMode.AspNetIdentity => HashModernPassword(user, password),
            _ => throw new InvalidOperationException("Chế độ ghi mật khẩu legacy không hợp lệ.")
        };

    public string HashModernPassword(LegacyUser user, string password) =>
        passwordHasher.HashPassword(user, password);

    private static bool VerifyLegacyMd5(string storedHash, string password)
    {
        if (storedHash.Length != 32)
        {
            return false;
        }

        byte[] expectedHash;
        try
        {
            expectedHash = Convert.FromHexString(storedHash);
        }
        catch (FormatException)
        {
            return false;
        }

        var utf8Hash = MD5.HashData(Encoding.UTF8.GetBytes(password));
        if (CryptographicOperations.FixedTimeEquals(expectedHash, utf8Hash))
        {
            return true;
        }

        var unicodeHash = MD5.HashData(Encoding.Unicode.GetBytes(password));
        return CryptographicOperations.FixedTimeEquals(expectedHash, unicodeHash);
    }

    private static string HashMd5(string password, Encoding encoding) =>
        Convert.ToHexString(MD5.HashData(encoding.GetBytes(password)));
}
