using System.ComponentModel.DataAnnotations;
using EmployeeManagement.Api.Common.Exceptions;
using EmployeeManagement.Api.Data.Legacy;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace EmployeeManagement.Api.Features.Auth;

public sealed class AuthService(
    LegacyAuthDbContext dbContext,
    ILegacyPasswordService passwordService,
    IJwtTokenService jwtTokenService,
    IOptions<LegacyAuthOptions> options) : IAuthService
{
    private const string InvalidCredentialsMessage = "Tên đăng nhập hoặc mật khẩu không đúng.";
    private readonly LegacyAuthOptions legacyAuthOptions = options.Value;

    public async Task<LoginResponse> LoginAsync(
        LoginRequest request,
        CancellationToken cancellationToken)
    {
        var userName = request.UserName.Trim();
        var user = await dbContext.Users
            .SingleOrDefaultAsync(item => item.UserName == userName, cancellationToken);

        if (user is null || user.Disable == true)
        {
            throw new UnauthorizedException(InvalidCredentialsMessage);
        }

        var passwordVerification = passwordService.Verify(user, request.Password);
        if (!passwordVerification.IsValid)
        {
            throw new UnauthorizedException(InvalidCredentialsMessage);
        }

        if (passwordVerification.RequiresRehash &&
            (!passwordVerification.IsLegacyHash || legacyAuthOptions.UpgradeLegacyPasswordHash))
        {
            user.PasswordHash = passwordService.HashModernPassword(user, request.Password);
        }

        user.LastLoginTime = DateTime.UtcNow;
        await dbContext.SaveChangesAsync(cancellationToken);

        var currentUser = await BuildCurrentUserAsync(user, cancellationToken);
        var token = jwtTokenService.CreateToken(currentUser);

        return new LoginResponse(
            token.AccessToken,
            token.ExpiresAtUtc,
            currentUser.User,
            currentUser.Roles,
            currentUser.Functions);
    }

    public async Task<CurrentUserResponse> GetCurrentUserAsync(
        Guid userId,
        CancellationToken cancellationToken)
    {
        var user = await dbContext.Users
            .AsNoTracking()
            .SingleOrDefaultAsync(item => item.Id == userId, cancellationToken);

        if (user is null || user.Disable == true)
        {
            throw new UnauthorizedException("Phiên đăng nhập không còn hợp lệ.");
        }

        return await BuildCurrentUserAsync(user, cancellationToken);
    }

    public async Task ChangePasswordAsync(
        Guid userId,
        ChangePasswordRequest request,
        CancellationToken cancellationToken)
    {
        var user = await dbContext.Users
            .SingleOrDefaultAsync(item => item.Id == userId, cancellationToken);
        if (user is null || user.Disable == true)
        {
            throw new UnauthorizedException("Phiên đăng nhập không còn hợp lệ.");
        }

        if (!passwordService.Verify(user, request.CurrentPassword).IsValid)
        {
            throw new ValidationException("Mật khẩu hiện tại không đúng.");
        }

        if (request.CurrentPassword == request.NewPassword)
        {
            throw new ValidationException("Mật khẩu mới phải khác mật khẩu hiện tại.");
        }

        user.PasswordHash = passwordService.HashForStorage(user, request.NewPassword);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task<CurrentUserResponse> BuildCurrentUserAsync(
        LegacyUser user,
        CancellationToken cancellationToken)
    {
        var roles = await (
            from userRole in dbContext.UserRoles.AsNoTracking()
            join role in dbContext.Roles.AsNoTracking() on userRole.RoleId equals role.Id
            where userRole.UserId == user.Id
            select role.Name)
            .Distinct()
            .OrderBy(roleName => roleName)
            .ToListAsync(cancellationToken);

        var functionRows = await (
            from userRole in dbContext.UserRoles.AsNoTracking()
            join roleFunction in dbContext.RoleFunctions.AsNoTracking()
                on userRole.RoleId equals roleFunction.RoleId
            join function in dbContext.Functions.AsNoTracking()
                on roleFunction.FunctionId equals function.Id
            where userRole.UserId == user.Id
            select new FunctionAccessRow(
                function.Id,
                function.ParentFunctionId,
                function.Name,
                function.Description,
                roleFunction.Right ?? 0,
                function.PossibleRight ?? 0))
            .ToListAsync(cancellationToken);

        var functions = functionRows
            .GroupBy(row => new
            {
                row.Id,
                row.ParentFunctionId,
                row.Name,
                row.Description
            })
            .Select(group => new AuthFunctionResponse(
                group.Key.Id,
                group.Key.ParentFunctionId,
                group.Key.Name,
                group.Key.Description,
                group.Aggregate(0, (right, row) => right | row.Right),
                group.Aggregate(0, (right, row) => right | row.PossibleRight)))
            .Where(function => function.Right > 0)
            .OrderBy(function => function.Description)
            .ThenBy(function => function.Name)
            .ToList();

        return new CurrentUserResponse(
            new AuthUserResponse(
                user.Id,
                user.UserName,
                user.FullName,
                AsUtc(user.CreateTime),
                AsUtc(user.LastLoginTime)),
            roles,
            functions);
    }

    private static DateTime AsUtc(DateTime value) =>
        value.Kind == DateTimeKind.Utc
            ? value
            : DateTime.SpecifyKind(value, DateTimeKind.Utc);

    private sealed record FunctionAccessRow(
        Guid Id,
        Guid? ParentFunctionId,
        string Name,
        string Description,
        int Right,
        int PossibleRight);
}
