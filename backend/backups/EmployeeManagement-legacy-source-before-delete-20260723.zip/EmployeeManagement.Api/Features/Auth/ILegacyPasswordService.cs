using EmployeeManagement.Api.Data.Legacy;

namespace EmployeeManagement.Api.Features.Auth;

public interface ILegacyPasswordService
{
    LegacyPasswordVerification Verify(LegacyUser user, string password);

    string HashForStorage(LegacyUser user, string password);

    string HashModernPassword(LegacyUser user, string password);
}

public sealed record LegacyPasswordVerification(
    bool IsValid,
    bool RequiresRehash,
    bool IsLegacyHash);
