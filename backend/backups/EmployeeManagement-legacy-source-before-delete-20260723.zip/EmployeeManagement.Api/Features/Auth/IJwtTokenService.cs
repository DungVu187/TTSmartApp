namespace EmployeeManagement.Api.Features.Auth;

public interface IJwtTokenService
{
    JwtTokenResult CreateToken(CurrentUserResponse currentUser);
}
