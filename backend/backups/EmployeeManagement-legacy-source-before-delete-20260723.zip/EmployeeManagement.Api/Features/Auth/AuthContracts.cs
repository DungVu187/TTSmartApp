using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.Api.Features.Auth;

public sealed class LoginRequest
{
    [Required(ErrorMessage = "Tên đăng nhập là bắt buộc.")]
    [StringLength(20, ErrorMessage = "Tên đăng nhập không được vượt quá 20 ký tự.")]
    public string UserName { get; init; } = string.Empty;

    [Required(ErrorMessage = "Mật khẩu là bắt buộc.")]
    [StringLength(200, MinimumLength = 1, ErrorMessage = "Mật khẩu không hợp lệ.")]
    public string Password { get; init; } = string.Empty;
}

public sealed class ChangePasswordRequest
{
    [Required(ErrorMessage = "Mật khẩu hiện tại là bắt buộc.")]
    [StringLength(200, MinimumLength = 1, ErrorMessage = "Mật khẩu hiện tại không hợp lệ.")]
    public string CurrentPassword { get; init; } = string.Empty;

    [Required(ErrorMessage = "Mật khẩu mới là bắt buộc.")]
    [StringLength(200, MinimumLength = 6, ErrorMessage = "Mật khẩu mới phải có từ 6 đến 200 ký tự.")]
    public string NewPassword { get; init; } = string.Empty;
}

public sealed record AuthUserResponse(
    Guid Id,
    string UserName,
    string FullName,
    DateTime CreateTime,
    DateTime LastLoginTime);

public sealed record AuthFunctionResponse(
    Guid Id,
    Guid? ParentFunctionId,
    string Name,
    string Description,
    int Right,
    int PossibleRight);

public sealed record CurrentUserResponse(
    AuthUserResponse User,
    IReadOnlyList<string> Roles,
    IReadOnlyList<AuthFunctionResponse> Functions);

public sealed record LoginResponse(
    string AccessToken,
    DateTime ExpiresAtUtc,
    AuthUserResponse User,
    IReadOnlyList<string> Roles,
    IReadOnlyList<AuthFunctionResponse> Functions);

public sealed record JwtTokenResult(string AccessToken, DateTime ExpiresAtUtc);
