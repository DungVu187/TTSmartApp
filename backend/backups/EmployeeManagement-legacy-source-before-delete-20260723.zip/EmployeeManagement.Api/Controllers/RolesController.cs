using EmployeeManagement.Api.Common.Models;
using EmployeeManagement.Api.Features.AccessManagement;
using EmployeeManagement.Api.Features.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/roles")]
[Produces("application/json")]
public sealed class RolesController(IRoleAdministrationService service) : ControllerBase
{
    [Authorize(Policy = AccessPolicies.RolesRead)]
    [HttpGet]
    [ProducesResponseType<PagedResponse<RoleListItemResponse>>(StatusCodes.Status200OK)]
    public async Task<ActionResult<PagedResponse<RoleListItemResponse>>> GetPage(
        [FromQuery] RoleListQuery query,
        CancellationToken cancellationToken) =>
        Ok(await service.GetPageAsync(query, cancellationToken));

    [Authorize(Policy = AccessPolicies.RolesRead)]
    [HttpGet("{id:guid}")]
    [ProducesResponseType<RoleResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<RoleResponse>> GetById(
        Guid id,
        CancellationToken cancellationToken) =>
        Ok(await service.GetByIdAsync(id, cancellationToken));

    [Authorize(Policy = AccessPolicies.RolesWrite)]
    [HttpPost]
    [ProducesResponseType<RoleResponse>(StatusCodes.Status201Created)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<RoleResponse>> Create(
        [FromBody] CreateRoleRequest request,
        CancellationToken cancellationToken)
    {
        var response = await service.CreateAsync(request, cancellationToken);
        return CreatedAtAction(nameof(GetById), new { id = response.Id }, response);
    }

    [Authorize(Policy = AccessPolicies.RolesWrite)]
    [HttpPut("{id:guid}")]
    [ProducesResponseType<RoleResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<RoleResponse>> Update(
        Guid id,
        [FromBody] UpdateRoleRequest request,
        CancellationToken cancellationToken) =>
        Ok(await service.UpdateAsync(id, request, cancellationToken));

    [Authorize(Policy = AccessPolicies.RolesWrite)]
    [HttpPut("{id:guid}/functions")]
    [ProducesResponseType<RoleResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<RoleResponse>> SetFunctions(
        Guid id,
        [FromBody] SetRoleFunctionsRequest request,
        CancellationToken cancellationToken) =>
        Ok(await service.SetFunctionsAsync(id, request, cancellationToken));

    [Authorize(Policy = AccessPolicies.RolesWrite)]
    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
    {
        await service.DeleteAsync(id, cancellationToken);
        return NoContent();
    }
}
