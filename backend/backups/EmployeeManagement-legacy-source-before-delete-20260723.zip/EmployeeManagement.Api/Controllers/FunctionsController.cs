using EmployeeManagement.Api.Features.AccessManagement;
using EmployeeManagement.Api.Features.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/functions")]
[Produces("application/json")]
public sealed class FunctionsController(IFunctionAdministrationService service) : ControllerBase
{
    [Authorize(Policy = AccessPolicies.FunctionsRead)]
    [HttpGet]
    [ProducesResponseType<IReadOnlyList<FunctionResponse>>(StatusCodes.Status200OK)]
    public async Task<ActionResult<IReadOnlyList<FunctionResponse>>> GetList(
        [FromQuery] FunctionListQuery query,
        CancellationToken cancellationToken) =>
        Ok(await service.GetListAsync(query, cancellationToken));

    [Authorize(Policy = AccessPolicies.FunctionsRead)]
    [HttpGet("{id:guid}")]
    [ProducesResponseType<FunctionResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<FunctionResponse>> GetById(
        Guid id,
        CancellationToken cancellationToken) =>
        Ok(await service.GetByIdAsync(id, cancellationToken));

    [Authorize(Policy = AccessPolicies.FunctionsWrite)]
    [HttpPost]
    [ProducesResponseType<FunctionResponse>(StatusCodes.Status201Created)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<FunctionResponse>> Create(
        [FromBody] CreateFunctionRequest request,
        CancellationToken cancellationToken)
    {
        var response = await service.CreateAsync(request, cancellationToken);
        return CreatedAtAction(nameof(GetById), new { id = response.Id }, response);
    }

    [Authorize(Policy = AccessPolicies.FunctionsWrite)]
    [HttpPut("{id:guid}")]
    [ProducesResponseType<FunctionResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<FunctionResponse>> Update(
        Guid id,
        [FromBody] UpdateFunctionRequest request,
        CancellationToken cancellationToken) =>
        Ok(await service.UpdateAsync(id, request, cancellationToken));

    [Authorize(Policy = AccessPolicies.FunctionsWrite)]
    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
    {
        await service.DeleteAsync(id, cancellationToken);
        return NoContent();
    }
}
