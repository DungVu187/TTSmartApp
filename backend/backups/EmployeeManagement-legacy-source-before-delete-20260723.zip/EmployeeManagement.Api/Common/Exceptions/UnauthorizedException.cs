namespace EmployeeManagement.Api.Common.Exceptions;

public sealed class UnauthorizedException(string message) : Exception(message);
