using System.Security.Claims;
using EmployeeManagement.Api.Common.Exceptions;

namespace EmployeeManagement.Api.Common.Security;

public static class ClaimsPrincipalExtensions
{
    public static Guid GetRequiredUserId(this ClaimsPrincipal principal)
    {
        var userIdValue = principal.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!Guid.TryParse(userIdValue, out var userId))
        {
            throw new UnauthorizedException("Token đăng nhập không hợp lệ.");
        }

        return userId;
    }
}
