using System.Security.Claims;
using System.Text;
using System.Text.Json;
using EmployeeManagement.Api.Common.Exceptions;
using EmployeeManagement.Api.Common.OpenApi;
using EmployeeManagement.Api.Data.Legacy;
using EmployeeManagement.Api.Features.AccessManagement;
using EmployeeManagement.Api.Features.Auth;
using EmployeeManagement.Api.Features.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

var authConnectionString = builder.Configuration.GetConnectionString("AuthConnection")
    ?? throw new InvalidOperationException("Chưa cấu hình ConnectionStrings:AuthConnection.");
var jwtOptions = builder.Configuration.GetSection(JwtOptions.SectionName).Get<JwtOptions>()
    ?? throw new InvalidOperationException("Chưa cấu hình Jwt.");

if (string.IsNullOrWhiteSpace(jwtOptions.Issuer) ||
    string.IsNullOrWhiteSpace(jwtOptions.Audience) ||
    jwtOptions.SigningKey.Length < 32 ||
    jwtOptions.AccessTokenMinutes <= 0)
{
    throw new InvalidOperationException("Cấu hình JWT không hợp lệ.");
}

builder.Services.AddProblemDetails(options =>
{
    options.CustomizeProblemDetails = context =>
    {
        context.ProblemDetails.Extensions["traceId"] = context.HttpContext.TraceIdentifier;
    };
});
builder.Services.AddExceptionHandler<ApiExceptionHandler>();
builder.Services.AddDbContext<LegacyAuthDbContext>(options =>
    options.UseSqlServer(authConnectionString, sqlServerOptions =>
    {
        sqlServerOptions.UseCompatibilityLevel(100);
        sqlServerOptions.MigrationsHistoryTable("__AuthMigrationsHistory");
    }));
builder.Services.Configure<JwtOptions>(builder.Configuration.GetSection(JwtOptions.SectionName));
builder.Services
    .AddOptions<LegacyAuthOptions>()
    .Bind(builder.Configuration.GetSection(LegacyAuthOptions.SectionName))
    .Validate(
        options => Enum.IsDefined(options.PasswordWriteMode),
        "LegacyAuth:PasswordWriteMode không hợp lệ.")
    .ValidateOnStart();
builder.Services.AddScoped<IPasswordHasher<LegacyUser>, PasswordHasher<LegacyUser>>();
builder.Services.AddScoped<ILegacyPasswordService, LegacyPasswordService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IUserAdministrationService, UserAdministrationService>();
builder.Services.AddScoped<IRoleAdministrationService, RoleAdministrationService>();
builder.Services.AddScoped<IFunctionAdministrationService, FunctionAdministrationService>();
builder.Services.AddSingleton<IJwtTokenService, JwtTokenService>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<IAuthorizationHandler, FunctionAccessHandler>();
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.MapInboundClaims = false;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwtOptions.Issuer,
            ValidateAudience = true,
            ValidAudience = jwtOptions.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtOptions.SigningKey)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1),
            NameClaimType = ClaimTypes.Name,
            RoleClaimType = ClaimTypes.Role
        };

        options.Events = new JwtBearerEvents
        {
            OnTokenValidated = async context =>
            {
                var userIdValue = context.Principal?.FindFirstValue(ClaimTypes.NameIdentifier);
                if (!Guid.TryParse(userIdValue, out var userId))
                {
                    context.Fail("Token đăng nhập không hợp lệ.");
                    return;
                }

                var authDbContext = context.HttpContext.RequestServices
                    .GetRequiredService<LegacyAuthDbContext>();
                var isActiveUser = await authDbContext.Users
                    .AsNoTracking()
                    .AnyAsync(
                        user => user.Id == userId && user.Disable != true,
                        context.HttpContext.RequestAborted);

                if (!isActiveUser)
                {
                    context.Fail("Phiên đăng nhập không còn hợp lệ.");
                }
            },
            OnChallenge = async context =>
            {
                context.HandleResponse();
                await WriteAuthorizationProblemAsync(
                    context.HttpContext,
                    StatusCodes.Status401Unauthorized,
                    "Chưa đăng nhập",
                    "Token đăng nhập bị thiếu, không hợp lệ hoặc đã hết hạn.");
            },
            OnForbidden = context => WriteAuthorizationProblemAsync(
                context.HttpContext,
                StatusCodes.Status403Forbidden,
                "Không có quyền truy cập",
                "Tài khoản không có quyền thực hiện chức năng này.")
        };
    });
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy(AccessPolicies.UsersRead, policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.AddRequirements(new FunctionAccessRequirement("FrmDsUser"));
    });
    options.AddPolicy(AccessPolicies.UsersWrite, policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.AddRequirements(new FunctionAccessRequirement("FrmEditUser"));
    });
    options.AddPolicy(AccessPolicies.RolesRead, policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.AddRequirements(new FunctionAccessRequirement("FrmDsRole"));
    });
    options.AddPolicy(AccessPolicies.RolesWrite, policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.AddRequirements(new FunctionAccessRequirement("FrmEditRole"));
    });
    options.AddPolicy(AccessPolicies.FunctionsRead, policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.AddRequirements(new FunctionAccessRequirement("FrmDsRole", "FrmEditRole"));
    });
    options.AddPolicy(AccessPolicies.FunctionsWrite, policy =>
    {
        policy.RequireAuthenticatedUser();
        policy.AddRequirements(new FunctionAccessRequirement("FrmEditRole"));
    });
});
builder.Services
    .AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.DictionaryKeyPolicy = JsonNamingPolicy.CamelCase;
    });
builder.Services.AddOpenApi(options =>
{
    options.AddDocumentTransformer<BearerSecuritySchemeTransformer>();
    options.AddOperationTransformer<AuthOperationTransformer>();
});

var app = builder.Build();

app.UseExceptionHandler();
app.UseAuthentication();
app.UseAuthorization();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.MapControllers();

app.Run();

static async Task WriteAuthorizationProblemAsync(
    HttpContext httpContext,
    int statusCode,
    string title,
    string detail)
{
    if (httpContext.Response.HasStarted)
    {
        return;
    }

    httpContext.Response.StatusCode = statusCode;
    var problemDetailsService = httpContext.RequestServices
        .GetRequiredService<IProblemDetailsService>();

    await problemDetailsService.TryWriteAsync(new ProblemDetailsContext
    {
        HttpContext = httpContext,
        ProblemDetails = new ProblemDetails
        {
            Status = statusCode,
            Title = title,
            Detail = detail,
            Instance = httpContext.Request.Path
        }
    });
}
