namespace EmployeeManagement.Api.Data.Legacy;

public sealed class LegacyUser
{
    public Guid Id { get; set; }

    public string UserName { get; set; } = string.Empty;

    public string PasswordHash { get; set; } = string.Empty;

    public string FullName { get; set; } = string.Empty;

    public DateTime CreateTime { get; set; }

    public DateTime LastLoginTime { get; set; }

    public bool? Disable { get; set; }

    public ICollection<LegacyUserRole> UserRoles { get; } = [];
}

public sealed class LegacyRole
{
    public Guid Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public ICollection<LegacyUserRole> UserRoles { get; } = [];

    public ICollection<LegacyRoleFunction> RoleFunctions { get; } = [];
}

public sealed class LegacyUserRole
{
    public Guid Id { get; set; }

    public Guid UserId { get; set; }

    public Guid RoleId { get; set; }

    public LegacyUser User { get; set; } = null!;

    public LegacyRole Role { get; set; } = null!;
}

public sealed class LegacyFunction
{
    public Guid Id { get; set; }

    public Guid? ParentFunctionId { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public int? PossibleRight { get; set; }

    public ICollection<LegacyRoleFunction> RoleFunctions { get; } = [];
}

public sealed class LegacyRoleFunction
{
    public Guid Id { get; set; }

    public Guid RoleId { get; set; }

    public Guid FunctionId { get; set; }

    public int? Right { get; set; }

    public LegacyRole Role { get; set; } = null!;

    public LegacyFunction Function { get; set; } = null!;
}
