using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Api.Data.Legacy;

public sealed class LegacyAuthDbContext(DbContextOptions<LegacyAuthDbContext> options)
    : DbContext(options)
{
    public DbSet<LegacyUser> Users => Set<LegacyUser>();

    public DbSet<LegacyRole> Roles => Set<LegacyRole>();

    public DbSet<LegacyUserRole> UserRoles => Set<LegacyUserRole>();

    public DbSet<LegacyFunction> Functions => Set<LegacyFunction>();

    public DbSet<LegacyRoleFunction> RoleFunctions => Set<LegacyRoleFunction>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        ConfigureUser(modelBuilder);
        ConfigureRole(modelBuilder);
        ConfigureUserRole(modelBuilder);
        ConfigureFunction(modelBuilder);
        ConfigureRoleFunction(modelBuilder);
        base.OnModelCreating(modelBuilder);
    }

    private static void ConfigureUser(ModelBuilder modelBuilder)
    {
        var builder = modelBuilder.Entity<LegacyUser>();
        builder.ToTable("User", "dbo", tableBuilder =>
            tableBuilder.UseSqlOutputClause(false));
        builder.HasKey(user => user.Id).HasName("PK_User");
        builder.Property(user => user.Id).HasColumnName("ID").HasDefaultValueSql("(newid())");
        builder.Property(user => user.UserName).HasMaxLength(20).IsRequired();
        builder.Property(user => user.PasswordHash).HasColumnName("Password").HasMaxLength(200).IsRequired();
        builder.Property(user => user.FullName).HasMaxLength(50).IsRequired();
        builder.Property(user => user.CreateTime).HasColumnType("datetime");
        builder.Property(user => user.LastLoginTime).HasColumnType("datetime");
    }

    private static void ConfigureRole(ModelBuilder modelBuilder)
    {
        var builder = modelBuilder.Entity<LegacyRole>();
        builder.ToTable("Role", "dbo", tableBuilder =>
            tableBuilder.UseSqlOutputClause(false));
        builder.HasKey(role => role.Id).HasName("PK_Role");
        builder.Property(role => role.Id).HasColumnName("ID").HasDefaultValueSql("(newid())");
        builder.Property(role => role.Name).HasMaxLength(50).IsRequired();
        builder.Property(role => role.Description).HasMaxLength(200).IsRequired();
    }

    private static void ConfigureUserRole(ModelBuilder modelBuilder)
    {
        var builder = modelBuilder.Entity<LegacyUserRole>();
        builder.ToTable("User_Role", "dbo", tableBuilder =>
            tableBuilder.UseSqlOutputClause(false));
        builder.HasKey(userRole => new { userRole.UserId, userRole.RoleId }).HasName("PK_User_Role");
        builder.Property(userRole => userRole.Id).HasColumnName("ID").HasDefaultValueSql("(newid())");
        builder.Property(userRole => userRole.UserId).HasColumnName("UserID");
        builder.Property(userRole => userRole.RoleId).HasColumnName("RoleID");
        builder.HasIndex(userRole => userRole.Id).IsUnique();
        builder.HasOne(userRole => userRole.User)
            .WithMany(user => user.UserRoles)
            .HasForeignKey(userRole => userRole.UserId);
        builder.HasOne(userRole => userRole.Role)
            .WithMany(role => role.UserRoles)
            .HasForeignKey(userRole => userRole.RoleId);
    }

    private static void ConfigureFunction(ModelBuilder modelBuilder)
    {
        var builder = modelBuilder.Entity<LegacyFunction>();
        builder.ToTable("Function", "dbo", tableBuilder =>
            tableBuilder.UseSqlOutputClause(false));
        builder.HasKey(function => function.Id).HasName("PK_Function_1");
        builder.Property(function => function.Id).HasColumnName("ID").HasDefaultValueSql("(newid())");
        builder.Property(function => function.ParentFunctionId).HasColumnName("ParentFunctionID");
        builder.Property(function => function.Name).HasMaxLength(50).IsRequired();
        builder.Property(function => function.Description).HasMaxLength(100).IsRequired();
        builder.Property(function => function.PossibleRight).HasColumnName("PosibleRight");
        builder.HasIndex(function => function.Name).IsUnique().HasDatabaseName("IX_Function");
    }

    private static void ConfigureRoleFunction(ModelBuilder modelBuilder)
    {
        var builder = modelBuilder.Entity<LegacyRoleFunction>();
        builder.ToTable("Role_Function", "dbo", tableBuilder =>
            tableBuilder.UseSqlOutputClause(false));
        builder.HasKey(roleFunction => new { roleFunction.RoleId, roleFunction.FunctionId })
            .HasName("PK_Role_Function_1");
        builder.Property(roleFunction => roleFunction.Id).HasColumnName("ID").HasDefaultValueSql("(newid())");
        builder.Property(roleFunction => roleFunction.RoleId).HasColumnName("RoleID");
        builder.Property(roleFunction => roleFunction.FunctionId).HasColumnName("FunctionID");
        builder.Property(roleFunction => roleFunction.Right).HasColumnName("Right");
        builder.HasIndex(roleFunction => roleFunction.Id).IsUnique();
        builder.HasOne(roleFunction => roleFunction.Role)
            .WithMany(role => role.RoleFunctions)
            .HasForeignKey(roleFunction => roleFunction.RoleId);
        builder.HasOne(roleFunction => roleFunction.Function)
            .WithMany(function => function.RoleFunctions)
            .HasForeignKey(roleFunction => roleFunction.FunctionId);
    }
}
