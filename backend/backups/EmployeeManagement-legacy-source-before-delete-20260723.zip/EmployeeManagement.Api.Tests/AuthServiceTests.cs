using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using EmployeeManagement.Api.Common.Exceptions;
using EmployeeManagement.Api.Data.Legacy;
using EmployeeManagement.Api.Features.Auth;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace EmployeeManagement.Api.Tests;

public sealed class AuthServiceTests
{
    [Fact]
    public async Task LoginAsync_MatKhauHashHopLe_TraTokenVaiTroVaChucNang()
    {
        await using var dbContext = CreateDbContext();
        var passwordHasher = new PasswordHasher<LegacyUser>();
        var user = await SeedAccessDataAsync(dbContext, passwordHasher, "Password@123", false);
        var service = CreateService(dbContext, passwordHasher);

        var response = await service.LoginAsync(
            new LoginRequest
            {
                UserName = user.UserName,
                Password = "Password@123"
            },
            CancellationToken.None);

        Assert.False(string.IsNullOrWhiteSpace(response.AccessToken));
        Assert.Contains("Mobile Admin", response.Roles);
        var function = Assert.Single(response.Functions);
        Assert.Equal("employees", function.Name);
        Assert.Equal(14, function.Right);
        Assert.True(response.ExpiresAtUtc > DateTime.UtcNow);

        var jwt = new JwtSecurityTokenHandler().ReadJwtToken(response.AccessToken);
        Assert.Contains(
            jwt.Claims,
            claim => claim.Type == ClaimTypes.Role && claim.Value == "Mobile Admin");
        Assert.Contains(
            jwt.Claims,
            claim => claim.Type == "function" && claim.Value == "employees:14");
    }

    [Fact]
    public async Task LoginAsync_MatKhauMd5Legacy_TuDongNangCapPasswordHash()
    {
        await using var dbContext = CreateDbContext();
        var passwordHasher = new PasswordHasher<LegacyUser>();
        var user = await SeedAccessDataAsync(dbContext, passwordHasher, "Legacy@123", true);
        var legacyHash = user.PasswordHash;
        var service = CreateService(dbContext, passwordHasher, upgradeLegacyPasswordHash: true);

        await service.LoginAsync(
            new LoginRequest
            {
                UserName = user.UserName,
                Password = "Legacy@123"
            },
            CancellationToken.None);

        var updatedUser = await dbContext.Users.SingleAsync(item => item.Id == user.Id);
        Assert.NotEqual(legacyHash, updatedUser.PasswordHash);
        Assert.StartsWith("AQAAAA", updatedUser.PasswordHash);
    }

    [Fact]
    public async Task LoginAsync_MatKhauMd5Legacy_MacDinhGiuNguyenHash()
    {
        await using var dbContext = CreateDbContext();
        var passwordHasher = new PasswordHasher<LegacyUser>();
        var user = await SeedAccessDataAsync(dbContext, passwordHasher, "Legacy@123", true);
        var legacyHash = user.PasswordHash;
        var service = CreateService(dbContext, passwordHasher);

        await service.LoginAsync(
            new LoginRequest
            {
                UserName = user.UserName,
                Password = "Legacy@123"
            },
            CancellationToken.None);

        var updatedUser = await dbContext.Users.SingleAsync(item => item.Id == user.Id);
        Assert.Equal(legacyHash, updatedUser.PasswordHash);
    }

    [Fact]
    public async Task LoginAsync_SaiMatKhau_ThrowUnauthorizedException()
    {
        await using var dbContext = CreateDbContext();
        var passwordHasher = new PasswordHasher<LegacyUser>();
        var user = await SeedAccessDataAsync(dbContext, passwordHasher, "Password@123", false);
        var service = CreateService(dbContext, passwordHasher);

        var exception = await Assert.ThrowsAsync<UnauthorizedException>(() =>
            service.LoginAsync(
                new LoginRequest
                {
                    UserName = user.UserName,
                    Password = "WrongPassword"
                },
                CancellationToken.None));

        Assert.Equal("Tên đăng nhập hoặc mật khẩu không đúng.", exception.Message);
    }

    [Fact]
    public async Task LoginAsync_TaiKhoanBiKhoa_ThrowUnauthorizedException()
    {
        await using var dbContext = CreateDbContext();
        var passwordHasher = new PasswordHasher<LegacyUser>();
        var user = await SeedAccessDataAsync(dbContext, passwordHasher, "Password@123", false);
        user.Disable = true;
        await dbContext.SaveChangesAsync();
        var service = CreateService(dbContext, passwordHasher);

        await Assert.ThrowsAsync<UnauthorizedException>(() =>
            service.LoginAsync(
                new LoginRequest
                {
                    UserName = user.UserName,
                    Password = "Password@123"
                },
                CancellationToken.None));
    }

    [Fact]
    public async Task ChangePasswordAsync_DungMatKhauHienTai_GhiHashLegacyMoi()
    {
        await using var dbContext = CreateDbContext();
        var passwordHasher = new PasswordHasher<LegacyUser>();
        var user = await SeedAccessDataAsync(dbContext, passwordHasher, "Password@123", false);
        var service = CreateService(dbContext, passwordHasher);

        await service.ChangePasswordAsync(
            user.Id,
            new ChangePasswordRequest
            {
                CurrentPassword = "Password@123",
                NewPassword = "NewPassword@123"
            },
            CancellationToken.None);

        var updatedUser = await dbContext.Users.SingleAsync(item => item.Id == user.Id);
        Assert.Equal(32, updatedUser.PasswordHash.Length);
        var passwordService = new LegacyPasswordService(
            passwordHasher,
            Options.Create(new LegacyAuthOptions()));
        Assert.True(passwordService.Verify(updatedUser, "NewPassword@123").IsValid);
    }

    private static LegacyAuthDbContext CreateDbContext()
    {
        var options = new DbContextOptionsBuilder<LegacyAuthDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        return new LegacyAuthDbContext(options);
    }

    private static AuthService CreateService(
        LegacyAuthDbContext dbContext,
        IPasswordHasher<LegacyUser> passwordHasher,
        bool upgradeLegacyPasswordHash = false)
    {
        var jwtOptions = Options.Create(new JwtOptions
        {
            Issuer = "EmployeeManagement.Api.Tests",
            Audience = "EmployeeManagement.Api.Tests",
            SigningKey = new string('k', 64),
            AccessTokenMinutes = 60
        });
        var legacyOptions = Options.Create(new LegacyAuthOptions
        {
            UpgradeLegacyPasswordHash = upgradeLegacyPasswordHash,
            PasswordWriteMode = LegacyPasswordWriteMode.Md5Utf8
        });
        var passwordService = new LegacyPasswordService(passwordHasher, legacyOptions);

        return new AuthService(
            dbContext,
            passwordService,
            new JwtTokenService(jwtOptions),
            legacyOptions);
    }

    private static async Task<LegacyUser> SeedAccessDataAsync(
        LegacyAuthDbContext dbContext,
        IPasswordHasher<LegacyUser> passwordHasher,
        string password,
        bool useLegacyMd5)
    {
        var now = DateTime.UtcNow;
        var user = new LegacyUser
        {
            Id = Guid.NewGuid(),
            UserName = "mobiletest",
            FullName = "Tài khoản kiểm thử",
            CreateTime = now,
            LastLoginTime = now,
            Disable = false
        };
        user.PasswordHash = useLegacyMd5
            ? Convert.ToHexString(MD5.HashData(Encoding.UTF8.GetBytes(password)))
            : passwordHasher.HashPassword(user, password);

        var role = new LegacyRole
        {
            Id = Guid.NewGuid(),
            Name = "Mobile Admin",
            Description = "Quản trị mobile"
        };
        var function = new LegacyFunction
        {
            Id = Guid.NewGuid(),
            Name = "employees",
            Description = "Quản lý nhân viên",
            PossibleRight = 15
        };

        dbContext.AddRange(
            user,
            role,
            function,
            new LegacyUserRole
            {
                Id = Guid.NewGuid(),
                UserId = user.Id,
                RoleId = role.Id
            },
            new LegacyRoleFunction
            {
                Id = Guid.NewGuid(),
                RoleId = role.Id,
                FunctionId = function.Id,
                Right = 14
            });
        await dbContext.SaveChangesAsync();

        return user;
    }
}
