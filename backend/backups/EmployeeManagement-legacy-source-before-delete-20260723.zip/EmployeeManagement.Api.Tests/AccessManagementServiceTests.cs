using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using EmployeeManagement.Api.Common.Exceptions;
using EmployeeManagement.Api.Data.Legacy;
using EmployeeManagement.Api.Features.AccessManagement;
using EmployeeManagement.Api.Features.Auth;
using EmployeeManagement.Api.Features.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace EmployeeManagement.Api.Tests;

public sealed class AccessManagementServiceTests
{
    [Fact]
    public async Task CreateUserAsync_DuLieuHopLe_TaoTaiKhoanVaGanRole()
    {
        await using var dbContext = CreateDbContext();
        var role = new LegacyRole
        {
            Id = Guid.NewGuid(),
            Name = "Quản trị",
            Description = "Quản trị hệ thống"
        };
        dbContext.Roles.Add(role);
        await dbContext.SaveChangesAsync();
        var service = new UserAdministrationService(dbContext, CreatePasswordService());

        var response = await service.CreateAsync(
            new CreateUserRequest
            {
                UserName = " mobileadmin ",
                FullName = " Quản trị Mobile ",
                Password = "Password@123",
                RoleIds = [role.Id]
            },
            CancellationToken.None);

        Assert.Equal("mobileadmin", response.UserName);
        Assert.Equal("Quản trị Mobile", response.FullName);
        Assert.False(response.Disabled);
        Assert.Equal(role.Id, Assert.Single(response.Roles).Id);
        var user = await dbContext.Users.SingleAsync(item => item.Id == response.Id);
        Assert.Equal(32, user.PasswordHash.Length);
    }

    [Fact]
    public async Task CreateUserAsync_TrungUserName_ThrowConflictException()
    {
        await using var dbContext = CreateDbContext();
        dbContext.Users.Add(CreateUser("duplicate"));
        await dbContext.SaveChangesAsync();
        var service = new UserAdministrationService(dbContext, CreatePasswordService());

        await Assert.ThrowsAsync<ConflictException>(() => service.CreateAsync(
            new CreateUserRequest
            {
                UserName = "duplicate",
                FullName = "Tài khoản trùng",
                Password = "Password@123"
            },
            CancellationToken.None));
    }

    [Fact]
    public async Task SetStatusAsync_TuKhoaTaiKhoan_ThrowConflictException()
    {
        await using var dbContext = CreateDbContext();
        var user = CreateUser("currentuser");
        dbContext.Users.Add(user);
        await dbContext.SaveChangesAsync();
        var service = new UserAdministrationService(dbContext, CreatePasswordService());

        await Assert.ThrowsAsync<ConflictException>(() => service.SetStatusAsync(
            user.Id,
            user.Id,
            new SetUserStatusRequest { Disabled = true },
            CancellationToken.None));
    }

    [Fact]
    public async Task SetFunctionsAsync_RightVuotPossibleRight_ThrowValidationException()
    {
        await using var dbContext = CreateDbContext();
        var role = new LegacyRole
        {
            Id = Guid.NewGuid(),
            Name = "Điều hành",
            Description = "Điều hành"
        };
        var function = new LegacyFunction
        {
            Id = Guid.NewGuid(),
            Name = "frmTest",
            Description = "Chức năng test",
            PossibleRight = 15
        };
        dbContext.AddRange(role, function);
        await dbContext.SaveChangesAsync();
        var service = new RoleAdministrationService(dbContext);

        await Assert.ThrowsAsync<ValidationException>(() => service.SetFunctionsAsync(
            role.Id,
            new SetRoleFunctionsRequest
            {
                Functions =
                [
                    new RoleFunctionAssignmentRequest
                    {
                        FunctionId = function.Id,
                        Right = 16
                    }
                ]
            },
            CancellationToken.None));
    }

    [Fact]
    public async Task SetFunctionsAsync_DuLieuHopLe_ThayTheMaTranQuyen()
    {
        await using var dbContext = CreateDbContext();
        var role = new LegacyRole
        {
            Id = Guid.NewGuid(),
            Name = "Điều hành",
            Description = "Điều hành"
        };
        var function = new LegacyFunction
        {
            Id = Guid.NewGuid(),
            Name = "frmTest",
            Description = "Chức năng test",
            PossibleRight = 15
        };
        dbContext.AddRange(
            role,
            function,
            new LegacyRoleFunction
            {
                Id = Guid.NewGuid(),
                RoleId = role.Id,
                FunctionId = function.Id,
                Right = 4
            });
        await dbContext.SaveChangesAsync();
        var service = new RoleAdministrationService(dbContext);

        var response = await service.SetFunctionsAsync(
            role.Id,
            new SetRoleFunctionsRequest
            {
                Functions =
                [
                    new RoleFunctionAssignmentRequest
                    {
                        FunctionId = function.Id,
                        Right = 14
                    }
                ]
            },
            CancellationToken.None);

        Assert.Equal(14, Assert.Single(response.Functions).Right);
        Assert.Equal(14, (await dbContext.RoleFunctions.SingleAsync()).Right);
    }

    [Fact]
    public async Task UpdateFunctionAsync_TaoVongLap_ThrowConflictException()
    {
        await using var dbContext = CreateDbContext();
        var parent = CreateFunction("frmParent", null);
        var child = CreateFunction("frmChild", parent.Id);
        dbContext.AddRange(parent, child);
        await dbContext.SaveChangesAsync();
        var service = new FunctionAdministrationService(dbContext);

        await Assert.ThrowsAsync<ConflictException>(() => service.UpdateAsync(
            parent.Id,
            new UpdateFunctionRequest
            {
                ParentFunctionId = child.Id,
                Name = parent.Name,
                Description = parent.Description,
                PossibleRight = 15
            },
            CancellationToken.None));
    }

    [Fact]
    public async Task DeleteFunctionAsync_DangGanChoRole_ThrowConflictException()
    {
        await using var dbContext = CreateDbContext();
        var role = new LegacyRole
        {
            Id = Guid.NewGuid(),
            Name = "Quản trị",
            Description = "Quản trị"
        };
        var function = CreateFunction("frmAssigned", null);
        dbContext.AddRange(
            role,
            function,
            new LegacyRoleFunction
            {
                Id = Guid.NewGuid(),
                RoleId = role.Id,
                FunctionId = function.Id,
                Right = 14
            });
        await dbContext.SaveChangesAsync();
        var service = new FunctionAdministrationService(dbContext);

        await Assert.ThrowsAsync<ConflictException>(() =>
            service.DeleteAsync(function.Id, CancellationToken.None));
    }

    [Fact]
    public async Task FunctionAccessHandler_QuyenThayDoiTrongDb_HieuLucNgay()
    {
        await using var dbContext = CreateDbContext();
        var user = CreateUser("permissionuser");
        var role = new LegacyRole
        {
            Id = Guid.NewGuid(),
            Name = "Quản trị",
            Description = "Quản trị"
        };
        var function = CreateFunction("FrmDsUser", null);
        var roleFunction = new LegacyRoleFunction
        {
            Id = Guid.NewGuid(),
            RoleId = role.Id,
            FunctionId = function.Id,
            Right = 14
        };
        dbContext.AddRange(
            user,
            role,
            function,
            new LegacyUserRole
            {
                Id = Guid.NewGuid(),
                UserId = user.Id,
                RoleId = role.Id
            },
            roleFunction);
        await dbContext.SaveChangesAsync();
        var httpContextAccessor = new HttpContextAccessor
        {
            HttpContext = new DefaultHttpContext()
        };
        var handler = new FunctionAccessHandler(dbContext, httpContextAccessor);
        var principal = new ClaimsPrincipal(new ClaimsIdentity(
            [new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())],
            "Test"));
        var requirement = new FunctionAccessRequirement("FrmDsUser");
        var allowedContext = new AuthorizationHandlerContext([requirement], principal, null);

        await handler.HandleAsync(allowedContext);

        Assert.True(allowedContext.HasSucceeded);
        roleFunction.Right = 0;
        await dbContext.SaveChangesAsync();
        var deniedContext = new AuthorizationHandlerContext([requirement], principal, null);

        await handler.HandleAsync(deniedContext);

        Assert.False(deniedContext.HasSucceeded);
    }

    private static LegacyAuthDbContext CreateDbContext()
    {
        var options = new DbContextOptionsBuilder<LegacyAuthDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        return new LegacyAuthDbContext(options);
    }

    private static ILegacyPasswordService CreatePasswordService() =>
        new LegacyPasswordService(
            new PasswordHasher<LegacyUser>(),
            Options.Create(new LegacyAuthOptions
            {
                PasswordWriteMode = LegacyPasswordWriteMode.Md5Utf8
            }));

    private static LegacyUser CreateUser(string userName)
    {
        var now = DateTime.UtcNow;
        return new LegacyUser
        {
            Id = Guid.NewGuid(),
            UserName = userName,
            PasswordHash = "0123456789ABCDEF0123456789ABCDEF",
            FullName = "Tài khoản kiểm thử",
            CreateTime = now,
            LastLoginTime = now,
            Disable = false
        };
    }

    private static LegacyFunction CreateFunction(string name, Guid? parentFunctionId) =>
        new()
        {
            Id = Guid.NewGuid(),
            ParentFunctionId = parentFunctionId,
            Name = name,
            Description = name,
            PossibleRight = 15
        };
}
